'''
Created on May 16, 2013

@author: csels
'''
import re
import datetime

traxisLog = 'TraxisServiceVerbose.log'
#Open and write initial line in CSV File (Later append)
csvFile = open("Export-AnalyzeRTSPTeardownTraxis.csv", "w+")
csvFile.write('Unique RTSP Teardown occurrences\n')
csvFile.close()

#Read Traxis log
print 'Analysis started at %s' % datetime.datetime.now().strftime("%Y-%m-%d %H:%M")
f=open(traxisLog, 'r')
with open(traxisLog, "r") as fobj:
    text = fobj.read()

#Find all request ID's for all RTSP Errors from Orbit or sent back to STB
#Save Request ID (of teardown)([0]), Session ID ([1]) and Teardown Reason ([3])  
regexRtspTeardownError = re.compile('.*\[RequestId = (.*)\].*\nTEARDOWN.*\n.*\nSession: (.*)\n(Reason: .*)', re.M|re.I)   
requestToRTSPTeardownMappings = re.findall(regexRtspTeardownError, text)

#Count all unique RTSP Errors
#Save all unique Session IDs for every RTSP Teardown Reason
uniqueRTSPTeardownReasons={}
uniquePRSessions={}
for r in requestToRTSPTeardownMappings:
    if r[2] not in uniqueRTSPTeardownReasons:
        uniqueRTSPTeardownReasons[r[2]] = 1
        uniquePRSessions[r[2]] = []
        uniquePRSessions[r[2]].append(r[1])
    else:
        uniqueRTSPTeardownReasons[r[2]] += 1
        uniquePRSessions[r[2]].append(r[1])

#Print dictionary: show the unique RTSP Teardown Reasons along with their count
totalRTSPTeardownOccurrences = 0

csvFile = open("Export-AnalyzeRTSPTeardownTraxis.csv", "a+")
for k,v in uniqueRTSPTeardownReasons.iteritems():
    print 'RTSP Teardown %s \t\t[found %sx in provided logs]' % (k,v)
    csvFile.write('%s,%s\n' % (k,v))
    totalRTSPTeardownOccurrences += v

#Write total sum of RTSP Teardown reasons to CSV
csvFile.write('Total RTSP Teardown Occurrences,%s\n' % totalRTSPTeardownOccurrences)
csvFile.close()

#Go through each session array in the dictionary for every RTSP Teardown reason    
for k,v in uniquePRSessions.iteritems():
    for PRSession in v:
        #Find the RTSP OK sent to STB for that Session ID
        #Correlate the Request ID for the RTSP Setup from this RTSP OK (Other than the RTSP Teardown request iD
        regexRtspResponsesOK = re.compile('.*\[RequestId = (.*?)\].*Message send to.*:\n(RTSP/1.0 200 OK\n.*\nSession: %s\n.*\nControlSession: .*\n.*\n.*\n.*\n.*\n.*)' % PRSession, re.MULTILINE) 
        okRequestIDs = re.findall(regexRtspResponsesOK, text)
        
        #Go through the array of OKRequestIDs tuples(okReply[0], okRrequestID[1])
        for okRequestID in okRequestIDs:
            #Find the RTSP Setup based on the Request ID in the OK Reply sent back to STB
            regexRtspSetup = re.compile('.*\[RequestId = %s\].*\n.*(SETUP.*RTSP/1.0.*)' % okRequestID[0], re.MULTILINE) 
            rtspSetups = re.findall(regexRtspSetup, text)
            
            #Finally print the unique RTSP Teardown Reason, corresponding RTSP Setup, and corresponding RTSP OK Reply to STB
            for rtspSetup in rtspSetups:    
                print '[RTSP Teardown %s]\n%s\n\t%s\n' % (k, rtspSetup, okRequestID[1].replace('\n', '\n\t'))

#Analysis ended timestamp            
print 'Analysis ended at %s' % datetime.datetime.now().strftime("%Y-%m-%d %H:%M")