'''
Created on May 16, 2013

@author: csels
'''
import re
import datetime

print 'Analysis started at %s' % datetime.datetime.now().strftime("%Y-%m-%d %H:%M")
#Read Traxis log
traxisLog = 'TraxisServiceVerbose.log'

f=open(traxisLog, 'r')
with open(traxisLog, "r") as fobj:
    text = fobj.read()

#Find all request ID's for all RTSP Errors from Orbit or sent back to STB
regexRtspOrbitError = re.compile('.*\[RequestId = (.*?)\].*\n.*(RTSP/1.0 [3-9][0-9]+?.*)', re.M|re.I)   
requestToRTSPErrorMappings = re.findall(regexRtspOrbitError, text)

#Count all unique RTSP Errors
uniqueRTSPErrors={}
uniqueSetups={}
for r in requestToRTSPErrorMappings:
    if r[1] != 'RTSP/1.0 451 Parameter Not Understood':
        if r[1] not in uniqueRTSPErrors:
            uniqueRTSPErrors[r[1]] = 1
            uniqueSetups[r[1]] = []
            uniqueSetups[r[1]].append(r[0])
        else:
            uniqueRTSPErrors[r[1]] += 1
            uniqueSetups[r[1]].append(r[0])

#Print unique RTSP Errors with their count
for k,v in uniqueRTSPErrors.iteritems():
    print 'Error %s \t\t[found %sx in provided logs]' % (k,v)
    
for k,v in uniqueSetups.iteritems():
    for request in v:
        regexRtspSetupForRequestId = re.compile('.*\[RequestId = %s\].*\n.*(SETUP.*RTSP/1.0.*)' % request, re.M|re.I) 
        rtspSetupsForRequestId = re.findall(regexRtspSetupForRequestId, text)
        
        for rtspSetupForRequestId in rtspSetupsForRequestId:
            print '[%s]\n%s' % (k, rtspSetupForRequestId)
            
print 'Analysis ended at %s' % datetime.datetime.now().strftime("%Y-%m-%d %H:%M")